﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;


namespace Ship.Models
{
    public class UpdateDateReceived
    {
        public int RecipientId { get; set; }

        [CustomValidation(typeof(Recipient), "DateValidation")]
        [Display(Name = "Date Received")]
        [DataType(DataType.Date)]
        public DateTime? DateReceived { get; set; }

        public static ValidationResult DateValidation(DateTime DateReceived, ValidationContext context)
        {
            if (DateReceived == null)
            {
                return ValidationResult.Success;
            }
            if (DateReceived < DateTime.Now)
            {
                return ValidationResult.Success;
            }
            return new ValidationResult("Delivered date must be before current date");
        }
    }
}
