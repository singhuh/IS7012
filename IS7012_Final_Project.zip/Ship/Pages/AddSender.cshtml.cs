﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Ship.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ship.Pages
{
    public class AddSenderModel : PageModel
    {
        private readonly ShipContext _context;
        public AddSenderModel(ShipContext context)
        {
            _context = context;
        }
        [BindProperty]
        public AddSender AddSender { get; set; }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var sender = new Sender();
            sender.SName = AddSender.SName;
            sender.SAddress = AddSender.SAddress;
            _context.Sender.Add(sender);
            _context.SaveChanges();
            return RedirectToPage("/Senders/Details", new { Id = sender.Id });


        }
    }
}
