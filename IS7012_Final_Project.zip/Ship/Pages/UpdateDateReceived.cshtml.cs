﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Ship.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Ship.Pages
{
    public class UpdateDateReceivedModel : PageModel
    {
        private readonly ShipContext _context;
        public UpdateDateReceivedModel(ShipContext context)
        {
            this._context = context;
        }
        public static bool RecipientIdGiven;
        [BindProperty]
        public UpdateDateReceived UpdateDateReceived { get; set; }
        public Recipient Recipient { get; set; }
        public IActionResult OnGet(int? id)
        {
            if (id == null)
            {
                RecipientIdGiven = false;
                return Page();
            }
            RecipientIdGiven = true;
            Recipient = _context.Recipient.Find(id);

            if (Recipient == null)
            {
                return NotFound();
            }
            UpdateDateReceived = new UpdateDateReceived();
            UpdateDateReceived.RecipientId = Recipient.Id;
            return Page();
        }
        public IActionResult OnPost()
        {
            Recipient = _context.Recipient.Find(UpdateDateReceived.RecipientId);
            if (!ModelState.IsValid)
            {
                return Page();
            }

            DateTime date;
            DateTime.TryParse(UpdateDateReceived.ToString(), out date);
            Recipient.DateReceived = date;

            this._context.SaveChanges();
            return RedirectToPage("/Recipients/Index", new { id = Recipient.Id });
        }

    }
}