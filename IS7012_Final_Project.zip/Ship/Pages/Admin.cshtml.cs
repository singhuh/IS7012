﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Ship.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Ship.Pages
{
    public class AdminModel : PageModel
    {
        private readonly ShipContext _context;
        public AdminModel(ShipContext context)
        {
            _context = context;
        }
        public void OnGet()
        {
            PopulateRecipientDropDown();
        }
        [BindProperty]
        public int RecipientId { get; set; }
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                PopulateRecipientDropDown();
                return Page();
            }
            return RedirectToPage("/UpdateDateReceived", new { Id = RecipientId });
        }
        private void PopulateRecipientDropDown()
        {
            var Recipients = _context.Recipient.OrderBy(x => x.Id);
            ViewData["Recipients"] = new SelectList(Recipients, "Id", "RName");
        }

    }
}